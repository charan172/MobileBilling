package com.cg.billing.boot;
import static org.assertj.core.api.Assertions.assertThat;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import com.cg.billing.beans.*;
import com.cg.billing.daoservices.*;
import com.cg.billing.exceptions.*;
import com.cg.billing.services.BillingServices;
import com.itextpdf.text.DocumentException;

@RunWith(SpringRunner.class)
@SpringBootTest
public class CgBillingSpringMvcJpaDataBootApplicationTests {

	@MockBean
	private  CustomerDAO customerDAO;
	@MockBean
	private PlanDAO planDAO;
	@MockBean
	private PostpaidDAO postpaidDAO;
	@MockBean
	private BillingDAO billingDAO;
	@Autowired
	private BillingServices billingServices;
	private static Customer customer1,customer2;
	private static PostpaidAccount postpaid1,postpaid2;
	private static Plan plan,plan2;
	private static Bill bill1,bill2;
	@Before
	public void setup() {
		customer1 = new Customer(101,"Charan", "Kothuri", "kothuri@kothuri", "05/12/2000", new Address(523155, "Chirala", "AP"));
		customer2= new Customer(102,"Charan", "Kothuri", "kothuri@kothuri", "05/12/2000", new Address(523155, "Chirala", "AP"));
		plan = new Plan(1,499,100,100,50,50,1000,0.10f,0.20f,0.05f,0.07f,0.03f,"pune","plan101");
		plan2 = new Plan(2,99,10,10,50,50,1000,0.10f,0.20f,0.05f,0.07f,0.03f,"pune","plan102");
		postpaid1 = new PostpaidAccount(955053783, plan, customer1);
		postpaid2 = new PostpaidAccount(955059999, plan2, customer1);
		bill1=new Bill(101,500,500,500,500,500,"January",794.14f,22.5f,31.5f,40.0f,80.0f,0.0f,60.57f,60.57f,postpaid1);
		bill2=new Bill(102,500,500,500,500,500,"May",794.14f,22.5f,31.5f,40.0f,80.0f,0.0f,60.57f,60.57f,postpaid1);	
	}

	@Test
	public void acceptCustomerDetailsTest() throws CustomerDetailsNotFoundException, BillingServicesDownException {
		Mockito.when(customerDAO.save(customer1)).thenReturn(customer1);
		assertThat(billingServices.acceptCustomerDetails(customer1)).isEqualTo(customer1);	
	}
	@Test
	public void getCustomerDetailsTest() throws CustomerDetailsNotFoundException, BillingServicesDownException {
		Mockito.when(customerDAO.findById(Mockito.anyInt())).thenReturn(Optional.of(customer1));
		assertThat(billingServices.getCustomerDetails(101)).isEqualTo(customer1);
	}
	@Test(expected =CustomerDetailsNotFoundException.class)
	public void getCustomerDetailsInvalidCustomerTest() throws CustomerDetailsNotFoundException, BillingServicesDownException {
		billingServices.getCustomerDetails(101);
	}
	@Test
	public void getAllCustomerDetailsTest() throws BillingServicesDownException {
		ArrayList<Customer> list = new ArrayList<>();
		list.add(customer1);
		list.add(customer2);
		Mockito.when(customerDAO.findAll()).thenReturn(list);
		assertThat(billingServices.getAllCustomerDetails()).isEqualTo(list);	
	}
	@Test
	public void getAllPlanDetailsTest() throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException {
		ArrayList<Plan> list = new ArrayList<>();
		list.add(plan);
		list.add(plan2);
		Mockito.when(planDAO.findAll()).thenReturn(list);
		assertThat(billingServices.getPlanAllDetails()).isEqualTo(list);
	}
	@Test
	public void openPostpaidMobileAccountTest() throws CustomerDetailsNotFoundException, PlanDetailsNotFoundException, BillingServicesDownException {
		Mockito.when(customerDAO.findById(Mockito.anyInt())).thenReturn(Optional.of(customer1));
		Mockito.when(planDAO.findById(Mockito.anyInt())).thenReturn(Optional.of(plan));
		Mockito.when(postpaidDAO.save(Mockito.any(PostpaidAccount.class))).thenReturn(postpaid1);
		assertThat(billingServices.openPostpaidMobileAccount(101, 1)).isEqualTo(955053783L);
	}
	@Test(expected =CustomerDetailsNotFoundException.class)
	public void invalidCustomerOpenPostpaidMobileAccountTest() throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException {
		billingServices.openPostpaidMobileAccount(103,101);
	}
	@Test(expected =PlanDetailsNotFoundException.class)
	public void invalidPlanOpenPostpaidMobileAccountTest() throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException {
		Mockito.when(customerDAO.findById(Mockito.anyInt())).thenReturn(Optional.of(customer1));
		billingServices.openPostpaidMobileAccount(101,11);
	}
	@Test
	public void getPostPaidAccountDetailsTest() throws CustomerDetailsNotFoundException, BillingServicesDownException, PostpaidAccountNotFoundException {
		Mockito.when(customerDAO.findById(Mockito.anyInt())).thenReturn(Optional.of(customer1));
		Mockito.when(postpaidDAO.getPostPaidAccountDetails(Mockito.any(Customer.class),Mockito.anyLong())).thenReturn(postpaid1);
		assertThat(billingServices.getPostPaidAccountDetails(101, 955053783)).isEqualTo(postpaid1);
	}
	@Test(expected =CustomerDetailsNotFoundException.class)
	public void invalidCustomergetPostpaidMobileAccountTest() throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException, PostpaidAccountNotFoundException {
		billingServices.getPostPaidAccountDetails(102,955053783);
	}
	@Test(expected =PostpaidAccountNotFoundException.class)
	public void invalidAccountOpenPostpaidMobileAccountTest() throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException, PostpaidAccountNotFoundException {
		Mockito.when(customerDAO.findById(Mockito.anyInt())).thenReturn(Optional.of(customer1));
		billingServices.getPostPaidAccountDetails(101,955053784);
	}
	@Test
	public void getAllPostPaidAccountDetailsTest() throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException, PostpaidAccountNotFoundException {
		ArrayList<PostpaidAccount> list = new ArrayList<>();
		list.add(postpaid1);
		list.add(postpaid2);
		Mockito.when(customerDAO.findById(Mockito.anyInt())).thenReturn(Optional.of(customer1));
		Mockito.when(postpaidDAO.getCustomerAllPostpaidAccountsDetails(Mockito.any(Customer.class))).thenReturn(list);
		assertThat(billingServices.getCustomerAllPostpaidAccountsDetails(101)).isEqualTo(list);
	}
	@Test(expected =PostpaidAccountNotFoundException.class)
	public void invalidAccountsgetPostpaidMobileAccountsTest() throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException, PostpaidAccountNotFoundException {
		Mockito.when(customerDAO.findById(Mockito.anyInt())).thenReturn(Optional.of(customer1));
		billingServices.getCustomerAllPostpaidAccountsDetails(101);
	}
	@Test(expected =CustomerDetailsNotFoundException.class)
	public void invalidCustomergetPostpaidMobileAccountsTest() throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException, PostpaidAccountNotFoundException {
		billingServices.getPostPaidAccountDetails(102,955053783);
	}
	@Test
	public void getMonthlyBillTest() throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException, PostpaidAccountNotFoundException, FileNotFoundException, InvalidBillMonthException, BillDetailsNotFoundException, DocumentException, IOException {
		Mockito.when(customerDAO.findById(Mockito.anyInt())).thenReturn(Optional.of(customer1));
		Mockito.when(postpaidDAO.getPostPaidAccountDetails(Mockito.any(Customer.class),Mockito.anyLong())).thenReturn(postpaid1);
		Mockito.when(billingDAO.getMonthlyBill(Mockito.any(PostpaidAccount.class),Mockito.anyString())).thenReturn(bill1);
		assertThat(billingServices.getMobileBillDetails(101, 955053783,"January")).isEqualTo(bill1);
	}
	@Test(expected =CustomerDetailsNotFoundException.class)
	public void invalidCustomergetMonthlyBillTest() throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException, PostpaidAccountNotFoundException, FileNotFoundException, InvalidBillMonthException, BillDetailsNotFoundException, DocumentException, IOException {
		billingServices.getMobileBillDetails(102,955053783,"January");
	}
	@Test(expected =PostpaidAccountNotFoundException.class)
	public void invalidAccountgetMonthlyBillTest() throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException, PostpaidAccountNotFoundException, FileNotFoundException, InvalidBillMonthException, BillDetailsNotFoundException, DocumentException, IOException {
		Mockito.when(customerDAO.findById(Mockito.anyInt())).thenReturn(Optional.of(customer1));
		billingServices.getMobileBillDetails(101,955053783,"January");
	}
	@Test(expected =BillDetailsNotFoundException.class)
	public void invalidBillgetMonthlyBillTest() throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException, PostpaidAccountNotFoundException, FileNotFoundException, InvalidBillMonthException, BillDetailsNotFoundException, DocumentException, IOException {
		Mockito.when(customerDAO.findById(Mockito.anyInt())).thenReturn(Optional.of(customer1));
		Mockito.when(postpaidDAO.getPostPaidAccountDetails(Mockito.any(Customer.class),Mockito.anyLong())).thenReturn(postpaid1);
		billingServices.getMobileBillDetails(101,955053783,"January");
	}
	@Test
	public void generateMonthlyBillTest() throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException, PostpaidAccountNotFoundException, FileNotFoundException, InvalidBillMonthException, BillDetailsNotFoundException, DocumentException, IOException {
		Mockito.when(customerDAO.findById(Mockito.anyInt())).thenReturn(Optional.of(customer1));
		Mockito.when(postpaidDAO.getPostPaidAccountDetails(Mockito.any(Customer.class),Mockito.anyLong())).thenReturn(postpaid1);
		Mockito.when(billingDAO.save(Mockito.any(Bill.class))).thenReturn(bill2);
		assertThat(billingServices.generateMonthlyMobileBill(101, 955053783, "May", 500, 500, 500, 500, 500)).isEqualTo(bill2);
	}
	@Test(expected =CustomerDetailsNotFoundException.class)
	public void invalidCustomergenerateMonthlyBillTest() throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException, PostpaidAccountNotFoundException, FileNotFoundException, InvalidBillMonthException, BillDetailsNotFoundException, DocumentException, IOException {
		billingServices.generateMonthlyMobileBill(101, 955053783, "May", 500, 500, 500, 500, 500);
	}
	@Test(expected =PostpaidAccountNotFoundException.class)
	public void invalidAccountgenerateMonthlyBillTest() throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException, PostpaidAccountNotFoundException, FileNotFoundException, InvalidBillMonthException, BillDetailsNotFoundException, DocumentException, IOException {
		Mockito.when(customerDAO.findById(Mockito.anyInt())).thenReturn(Optional.of(customer1));
		billingServices.generateMonthlyMobileBill(101, 955053783, "May", 500, 500, 500, 500, 500);
	}
	@Test
	public void getAllMonthlyBillTest() throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException, PostpaidAccountNotFoundException, FileNotFoundException, InvalidBillMonthException, BillDetailsNotFoundException, DocumentException, IOException {
		ArrayList<Bill>list=new ArrayList<>();
		list.add(bill1);
		list.add(bill2);
		Mockito.when(customerDAO.findById(Mockito.anyInt())).thenReturn(Optional.of(customer1));
		Mockito.when(postpaidDAO.getPostPaidAccountDetails(Mockito.any(Customer.class),Mockito.anyLong())).thenReturn(postpaid1);
		Mockito.when(billingDAO.getAllMonthsBills(Mockito.any(PostpaidAccount.class))).thenReturn(list);
		assertThat(billingServices.getCustomerPostPaidAccountAllBillDetails(101, 955053783)).isEqualTo(list);
	}
	@Test(expected =CustomerDetailsNotFoundException.class)
	public void invalidCustomergetAllMonthlyBillsTest() throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException, PostpaidAccountNotFoundException, FileNotFoundException, InvalidBillMonthException, BillDetailsNotFoundException, DocumentException, IOException {
		billingServices.getCustomerPostPaidAccountAllBillDetails(101, 955053783);
	}
	@Test(expected =PostpaidAccountNotFoundException.class)
	public void invalidAccountgetAllMonthlyBillsTest() throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException, PostpaidAccountNotFoundException, FileNotFoundException, InvalidBillMonthException, BillDetailsNotFoundException, DocumentException, IOException {
		Mockito.when(customerDAO.findById(Mockito.anyInt())).thenReturn(Optional.of(customer1));
		billingServices.getCustomerPostPaidAccountAllBillDetails(101, 955053783);
	}
	@Test(expected =BillDetailsNotFoundException.class)
	public void invalidBillgetAllMonthlyBillsTest() throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException, PostpaidAccountNotFoundException, FileNotFoundException, InvalidBillMonthException, BillDetailsNotFoundException, DocumentException, IOException {
		Mockito.when(customerDAO.findById(Mockito.anyInt())).thenReturn(Optional.of(customer1));
		Mockito.when(postpaidDAO.getPostPaidAccountDetails(Mockito.any(Customer.class),Mockito.anyLong())).thenReturn(postpaid1);
		billingServices.getCustomerPostPaidAccountAllBillDetails(101, 955053783);
	}
}