package com.cg.billing.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.billing.beans.Customer;
import com.cg.billing.beans.Plan;
import com.cg.billing.exceptions.BillingServicesDownException;
import com.cg.billing.services.BillingServices;

@Controller
public class PlanController {
	@Autowired
	private BillingServices billingServices;
	@RequestMapping(value="/getPlanAllDetails")
	public ModelAndView registerAssociateAction() {
		List<Plan> plans;
		try {
			plans = billingServices.getPlanAllDetails();
			return new ModelAndView("displayPlanAllDetails","plans",plans);
		} catch (BillingServicesDownException e) {
			return new ModelAndView("index","errorMessage",e.getMessage());
		}
	}
}
