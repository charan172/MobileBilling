package com.cg.billing.beans;
import java.util.Map;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;
import javax.persistence.TableGenerator;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
@Entity
@TableGenerator(name="seq_customerID",initialValue=1,allocationSize=1)
public class Customer {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO,generator="seq_customerID")
	private int customerID;
	@NotEmpty(message="First Name cannot be Empty")
	@Pattern(regexp = "^[a-zA-Z\\s]+$",message="Enter only characters")
	private String firstName;
	@NotEmpty(message="Last Name cannot be Empty")
	@Pattern(regexp = "^[a-zA-Z\\s]+$",message="Enter only characters")
	private String lastName;
	@NotEmpty(message="EmailId cannot be Empty")
	@Email
	private String emailID;
	@NotEmpty(message="Date Of Birth cannot be Empty")
	private String dateOfBirth;
	@Embedded
	private Address address;
	@OneToMany(fetch=FetchType.EAGER,mappedBy="customer")
	@MapKey
	private Map<Long, PostpaidAccount> postpaidAccounts;
	public Customer() {}
	public Customer(String firstName, String lastName, String emailID, String dateOfBirth, Address address) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailID = emailID;
		this.dateOfBirth = dateOfBirth;
		this.address = address;
	}
	
	public Customer(int customerID, String firstName, String lastName, String emailID, String dateOfBirth,
			Address address, Map<Long, PostpaidAccount> postpaidAccounts) {
		super();
		this.customerID = customerID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailID = emailID;
		this.dateOfBirth = dateOfBirth;
		this.address = address;
		this.postpaidAccounts = postpaidAccounts;
	}
	
	public Customer(int customerID, @NotEmpty String firstName, @NotEmpty String lastName, String emailID,
			String dateOfBirth, Address address) {
		super();
		this.customerID = customerID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailID = emailID;
		this.dateOfBirth = dateOfBirth;
		this.address = address;
	}
	public int getCustomerID() {
		return customerID;
	}
	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmailID() {
		return emailID;
	}
	public void setEmailID(String emailID) {
		this.emailID = emailID;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public Map<Long, PostpaidAccount> getPostpaidAccounts() {
		return postpaidAccounts;
	}
	public void setPostpaidAccounts(Map<Long, PostpaidAccount> postpaidAccounts) {
		this.postpaidAccounts = postpaidAccounts;
	}
	@Override
	public String toString() {
		return "Customer [customerID=" + customerID + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", emailID=" + emailID + ", dateOfBirth=" + dateOfBirth + ", address=" + address
				+ "]";
	}
	public Customer(int customerID) {
		super();
		this.customerID = customerID;
	}
	
}