package com.cg.billing.services;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.billing.beans.Address;
import com.cg.billing.beans.Bill;
import com.cg.billing.beans.Customer;
import com.cg.billing.beans.Plan;
import com.cg.billing.beans.PostpaidAccount;
import com.cg.billing.daoservices.BillingDAO;
import com.cg.billing.daoservices.CustomerDAO;
import com.cg.billing.daoservices.PlanDAO;
import com.cg.billing.daoservices.PostpaidDAO;
import com.cg.billing.exceptions.BillDetailsNotFoundException;
import com.cg.billing.exceptions.BillingServicesDownException;
import com.cg.billing.exceptions.CustomerDetailsNotFoundException;
import com.cg.billing.exceptions.InvalidBillMonthException;
import com.cg.billing.exceptions.PlanDetailsNotFoundException;
import com.cg.billing.exceptions.PostpaidAccountNotFoundException;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
@Component("billingServices")
public class BillingServicesImpl implements BillingServices {
	@Autowired
	private CustomerDAO customerDAO;
	@Autowired
	private PlanDAO planDAO;
	@Autowired
	private PostpaidDAO postpaidDAO;
	@Autowired
	private BillingDAO billingDAO;
	private static int flag=0;
	@Override
	public List<Plan> getPlanAllDetails() throws BillingServicesDownException {
		return planDAO.findAll();
	}

	@Override
	public Customer acceptCustomerDetails(Customer customer)
			throws BillingServicesDownException {
		if(flag==0) {
			Plan plan1=new Plan(101,499,100,100,50,50,1000,0.10f,0.20f,0.05f,0.07f,0.03f,"pune","plan101");
			planDAO.save(plan1);
			Plan plan2=new Plan(102,99,50,50,25,25,100,0.10f,0.20f,0.05f,0.07f,0.03f,"pune","plan102");
			planDAO.save(plan2);
			Plan plan3=new Plan(103,999,500,500,500,500,10000,0.10f,0.20f,0.05f,0.07f,0.03f,"pune","plan103");
			planDAO.save(plan3);
			flag++;
		}
		customer=customerDAO.save(customer);
		return customer;
	}

	@Override
	public long openPostpaidMobileAccount(int customerID, int planID)
			throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException {
		Customer customer=customerDAO.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException ("Customer details for customer"+customerID+"not found"));
		Plan plan=planDAO.findById(planID).orElseThrow(()->new PlanDetailsNotFoundException("Plan details for planID"+planID+"not found"));
		PostpaidAccount postpaidAccount=new PostpaidAccount(plan, customer);
		postpaidAccount=postpaidDAO.save(postpaidAccount);
		return postpaidAccount.getMobileNo();
	}

	@Override
	public Bill generateMonthlyMobileBill(int customerID, long mobileNo, String billMonth, int noOfLocalSMS,
			int noOfStdSMS, int noOfLocalCalls, int noOfStdCalls, int internetDataUsageUnits)
					throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
					BillingServicesDownException, PlanDetailsNotFoundException, BillDetailsNotFoundException {
		PostpaidAccount postpaid=getPostPaidAccountDetails(customerID, mobileNo);
		Bill billa=billingDAO.getMonthlyBill(postpaid, billMonth);
		if(billa!=null) throw new BillDetailsNotFoundException("Cannot generate 2 Bills for same month");
		Bill bill=new Bill(noOfLocalSMS, noOfStdSMS, noOfLocalCalls, noOfStdCalls, internetDataUsageUnits, postpaid, billMonth);
		if(noOfLocalSMS>postpaid.getPlan().getFreeLocalSMS())
			bill.setLocalSMSAmount((noOfLocalSMS-postpaid.getPlan().getFreeLocalSMS())*postpaid.getPlan().getLocalSMSRate());
		else
			bill.setLocalSMSAmount(0);
		if(noOfStdSMS>postpaid.getPlan().getFreeStdSMS())
			bill.setStdSMSAmount((noOfStdSMS-postpaid.getPlan().getFreeStdSMS())*postpaid.getPlan().getStdSMSRate());
		else
			bill.setStdSMSAmount(0);
		if(noOfLocalCalls>postpaid.getPlan().getFreeLocalCalls())
			bill.setLocalCallAmount((noOfLocalCalls-postpaid.getPlan().getFreeLocalCalls())*postpaid.getPlan().getLocalCallRate());
		else
			bill.setLocalCallAmount(0);
		if(noOfStdCalls>postpaid.getPlan().getFreeStdCalls())
			bill.setStdCallAmount((noOfStdCalls-postpaid.getPlan().getFreeStdCalls())*postpaid.getPlan().getStdCallRate());
		else
			bill.setStdCallAmount(0);
		if(internetDataUsageUnits>postpaid.getPlan().getFreeInternetDataUsageUnits())
			bill.setInternetDataUsageAmount((internetDataUsageUnits-postpaid.getPlan().getFreeInternetDataUsageUnits())*postpaid.getPlan().getInternetDataUsageRate());
		else
			bill.setInternetDataUsageAmount(0);
		float initialamount=bill.getLocalSMSAmount()+bill.getLocalCallAmount()+bill.getStdSMSAmount()+bill.getStdCallAmount()+bill.getInternetDataUsageAmount()+postpaid.getPlan().getMonthlyRental();
		bill.setCgst((initialamount*9)/100);
		bill.setSgst((initialamount*9)/100);
		bill.setTotalBillAmount(initialamount+bill.getCgst()+bill.getSgst());
		bill=billingDAO.save(bill);
		return bill;
	}

	@Override
	public Customer getCustomerDetails(int customerID)
			throws CustomerDetailsNotFoundException, BillingServicesDownException {
		Customer customer=customerDAO.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException ("Customer details for customer "+customerID+" not found"));
		return customer;
	}

	@Override
	public List<Customer> getAllCustomerDetails() throws BillingServicesDownException {
		return customerDAO.findAll();
	}

	@Override
	public PostpaidAccount getPostPaidAccountDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		Customer customer=getCustomerDetails(customerID);
		PostpaidAccount postpaidAccount=postpaidDAO.getPostPaidAccountDetails(customer,mobileNo);
		if(postpaidAccount==null) throw new PostpaidAccountNotFoundException("Requested PostPaid Account does not exist!!!");
		System.out.println(postpaidAccount);
		return postpaidAccount;
	}

	@Override
	public List<PostpaidAccount> getCustomerAllPostpaidAccountsDetails(int customerID)
			throws CustomerDetailsNotFoundException, BillingServicesDownException, PostpaidAccountNotFoundException {
		Customer customer=getCustomerDetails(customerID);
		ArrayList<PostpaidAccount>postpaidAccounts=postpaidDAO.getCustomerAllPostpaidAccountsDetails(customer);
		if(postpaidAccounts.isEmpty()) throw new PostpaidAccountNotFoundException("No PostPaid Accounts available with given customerID");
		return postpaidAccounts;
	}

	@Override
	public Bill getMobileBillDetails(int customerID, long mobileNo, String billMonth)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
			BillDetailsNotFoundException, BillingServicesDownException, DocumentException, IOException {
		PostpaidAccount postpaidAccount=getPostPaidAccountDetails(customerID, mobileNo);
		Bill bill=billingDAO.getMonthlyBill(postpaidAccount, billMonth);
		if(bill==null) throw new BillDetailsNotFoundException("No Bill is generated with given phoneNo and CustomerID for given Month");
		return bill;
	}
	@Override
	public ArrayList<Bill> getCustomerPostPaidAccountAllBillDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException,
			BillDetailsNotFoundException {
		PostpaidAccount postpaidAccount=getPostPaidAccountDetails(customerID, mobileNo);
		ArrayList<Bill>bills=billingDAO.getAllMonthsBills(postpaidAccount);
		if(bills.isEmpty()) throw new BillDetailsNotFoundException("No Bill is generated with given phoneNo and CustomerID");
		return bills;
	}

	@Override
	public boolean changePlan(int customerID, long mobileNo, int planID) throws CustomerDetailsNotFoundException,
	PostpaidAccountNotFoundException, PlanDetailsNotFoundException, BillingServicesDownException {
		Customer customer=getCustomerDetails(customerID);
		PostpaidAccount postpaidAccount=getPostPaidAccountDetails(customerID, mobileNo);
		Plan plan=planDAO.findById(planID).orElseThrow(()->new PlanDetailsNotFoundException ("Plan details for Plan"+planID+"not found"));
		PostpaidAccount postpaid=new PostpaidAccount(mobileNo, plan, customer);
		postpaidDAO.save(postpaid);
		return true;
	}

	@Override
	public boolean closeCustomerPostPaidAccount(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		Customer customer=getCustomerDetails(customerID);
		PostpaidAccount postpaidAccount=getPostPaidAccountDetails(customerID, mobileNo);
		billingDAO.deleteAllBills(postpaidAccount);		
		postpaidDAO.closeCustomerPostPaidAccount(customer,mobileNo);
		return true;
	}
	@Override
	public boolean deleteCustomer(int customerID)
			throws BillingServicesDownException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		ArrayList<PostpaidAccount>postpaidAccounts=(ArrayList<PostpaidAccount>) getCustomerAllPostpaidAccountsDetails(customerID);
		for(PostpaidAccount postpaidAccount:postpaidAccounts) {
			closeCustomerPostPaidAccount(customerID, postpaidAccount.getMobileNo());			
		}
		customerDAO.deleteById(customerID);
		return true;
	}
	@Override
	public Plan getCustomerPostPaidAccountPlanDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException,
			PlanDetailsNotFoundException {
		Customer customer=getCustomerDetails(customerID);
		Plan plan=postpaidDAO.getCustomerPostPaidAccountPlanDetails(customer,mobileNo);
		if(plan==null)throw new PlanDetailsNotFoundException("No Plan with given ID Available");
		return plan;
	}
}