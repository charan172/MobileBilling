package com.cg.billing.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;


import com.cg.billing.beans.Customer;

@Controller
public class URIController {
	Customer customer;
@RequestMapping("/")
public String getIndexPage(){
	return "index";
}
@RequestMapping("/indexPage")
public String backToIndexPage(){
	return "index";
}
@RequestMapping("/signup")
public String getSignupPage(){
	return "signup";
}
@RequestMapping("/getCustomerDetails")
public String getCustomerDetails(){
	return "getCustomerDetails";
}
@ModelAttribute
public Customer getAccount() {
	customer=new Customer();
	return customer;
}
@RequestMapping("/deleteCustomerDetails")
public String deleteCustomerDetails(){
	return "deleteCustomerDetails";
}
@RequestMapping("/openPostpaidMobileAccount")
public String openPostpaidMobileAccount(){
	return "openPostpaidMobileAccount";
}
@RequestMapping("/getPostPaidAccountDetails")
public String getPostPaidAccountDetails(){
	return "getPostPaidAccountDetails";
}
@RequestMapping("/getAllPostPaidAccountDetailsofCustomer")
public String getAllPostPaidAccountDetailsofCustomer(){
	return "getAllPostPaidAccountDetailsofCustomer";
}
@RequestMapping("/changePlan")
public String getchangePlan(){
	return "changePlan";
}
@RequestMapping("/closeCustomerPostPaidAccount")
public String closeCustomerPostPaidAccount(){
	return "closeCustomerPostPaidAccount";
}
@RequestMapping("/generateMonthlyMobileBill")
public String generateMonthlyMobileBill(){
	return "generateMonthlyMobileBill";
}
@RequestMapping("/getMobileBillDetails")
public String getMobileBillDetails(){
	return "getMobileBillDetails";
}
@RequestMapping("/getAllMobileBillDetails")
public String getAllMobileBillDetails(){
	return "getAllMobileBillDetails";
}

}
