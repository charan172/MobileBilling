package com.cg.billing.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.billing.beans.Plan;
import com.cg.billing.beans.PostpaidAccount;
import com.cg.billing.exceptions.BillingServicesDownException;
import com.cg.billing.exceptions.CustomerDetailsNotFoundException;
import com.cg.billing.exceptions.PlanDetailsNotFoundException;
import com.cg.billing.exceptions.PostpaidAccountNotFoundException;
import com.cg.billing.services.BillingServices;

@Controller
public class PostPaidAccountController {
	@Autowired
	private BillingServices billingServices;
	@RequestMapping(value="/createpostpaidAccount")
	public ModelAndView registerAssociateAction(@RequestParam("customerID")int customerID,@RequestParam("planID")int planID){
		long mobileNo;
		try {
			mobileNo = billingServices.openPostpaidMobileAccount(customerID, planID);
			return new ModelAndView("openPostpaidMobileAccount","Message","Account has been created with "+mobileNo);
		} catch (PlanDetailsNotFoundException | CustomerDetailsNotFoundException | BillingServicesDownException e) {
			return new ModelAndView("openPostpaidMobileAccount","errorMessage",e.getMessage());
		}
	}
	@RequestMapping(value="/displayPostPaidAccountDetails")
	public ModelAndView getPostPaidAccountDetails(@RequestParam("customerID")int customerID,@RequestParam("mobileNo")long mobileNo) {
		PostpaidAccount postpaidAccount;
		try {
			postpaidAccount = billingServices.getPostPaidAccountDetails(customerID, mobileNo);
			return new ModelAndView("displayPostPaidAccountDetails","postpaidAccount",postpaidAccount);
		} catch (CustomerDetailsNotFoundException | PostpaidAccountNotFoundException | BillingServicesDownException e) {
			return new ModelAndView("getPostPaidAccountDetails","errorMessage",e.getMessage());
		}
	}
	@RequestMapping(value="/displayAllPostPaidAccountDetailsofCustomer")
	public ModelAndView getAllPostPaidAccountDetails(@RequestParam("customerID")int customerID) {
		List<PostpaidAccount> postpaidAccount;
		try {
			postpaidAccount = billingServices.getCustomerAllPostpaidAccountsDetails(customerID);
			return new ModelAndView("displayAllPostPaidAccountDetails","postpaidAccount",postpaidAccount);
			} catch (CustomerDetailsNotFoundException | BillingServicesDownException | PostpaidAccountNotFoundException e) {
				return new ModelAndView("getAllPostPaidAccountDetailsofCustomer","errorMessage",e.getMessage());}
		}
		
	@RequestMapping(value="/changingPlan")
	public ModelAndView changePlanDetails(@RequestParam("customerID")int customerID,@RequestParam("planID")int planID,@RequestParam("mobileNo")long mobileNo){
		try {
			boolean postpaidAccount= billingServices.changePlan(customerID, mobileNo, planID);
			return new ModelAndView("changePlan","Message","Plan Has Been Succesfully Changed");
		} catch (CustomerDetailsNotFoundException | PostpaidAccountNotFoundException | PlanDetailsNotFoundException
				| BillingServicesDownException e) {
			return new ModelAndView("changePlan","errorMessage",e.getMessage());
		}}
	@RequestMapping(value="/closingPostPaidAccountDetails")
	public ModelAndView closeAccountDetails(@RequestParam("customerID")int customerID,@RequestParam("mobileNo")long mobileNo) {
		try {
			boolean postpaidAccount= billingServices.closeCustomerPostPaidAccount(customerID, mobileNo);
			return new ModelAndView("closeCustomerPostPaidAccount","Message","Account Has been Succesfully Closed");
		} catch (CustomerDetailsNotFoundException | PostpaidAccountNotFoundException | BillingServicesDownException e) {
			return new ModelAndView("closeCustomerPostPaidAccount","errorMessage",e.getMessage());
		}}
}
