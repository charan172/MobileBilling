package com.cg.billing.daoservices;
import java.util.ArrayList;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.billing.beans.Customer;
import com.cg.billing.beans.Plan;
import com.cg.billing.beans.PostpaidAccount;
public interface PostpaidDAO extends JpaRepository<PostpaidAccount, Integer>{
	@Query("select a from PostpaidAccount a where a.customer=:customer and a.mobileNo=:mobileNo")
	PostpaidAccount getPostPaidAccountDetails(@Param("customer")Customer customer, @Param("mobileNo")long mobileNo);
	@Query("select a from PostpaidAccount a where a.customer=:customer")
	ArrayList<PostpaidAccount> getCustomerAllPostpaidAccountsDetails(@Param("customer") Customer customer);
	@Transactional
	@Modifying
	@Query("delete from PostpaidAccount a where a.customer=:customer and a.mobileNo=:mobileNo")
	void closeCustomerPostPaidAccount(@Param("customer")Customer customer, @Param("mobileNo")long mobileNo);
	@Query("select a.plan from PostpaidAccount a where a.customer=:customer and a.mobileNo=:mobileNo")
	Plan getCustomerPostPaidAccountPlanDetails(Customer customer, long mobileNo);
	@Query("select a from PostpaidAccount a where a.mobileNo=:mobileNo")
	PostpaidAccount findById(@Param("mobileNo")long mobileNo);
	/*@Transactional
	@Modifying
	@Query("delete from PostpaidAccount a where a.mobileNo=:mobileNo")
	void deleteById(@Param("mobileNo")long mobileNo);*/
}