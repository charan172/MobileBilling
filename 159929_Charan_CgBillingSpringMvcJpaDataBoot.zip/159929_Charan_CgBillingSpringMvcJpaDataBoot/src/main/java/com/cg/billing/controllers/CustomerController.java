package com.cg.billing.controllers;

import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.billing.beans.Customer;
import com.cg.billing.exceptions.BillingServicesDownException;
import com.cg.billing.exceptions.CustomerDetailsNotFoundException;
import com.cg.billing.exceptions.PostpaidAccountNotFoundException;
import com.cg.billing.services.BillingServices;
@Controller
public class CustomerController {
	@Autowired
	private BillingServices billingServices;
	@RequestMapping(value="/registerCustomer")
	public ModelAndView registerAssociateAction(@Valid @ModelAttribute Customer customer,BindingResult bindingResult){
		if(bindingResult.hasErrors())
			return new ModelAndView("signup");
		try {
			customer=billingServices.acceptCustomerDetails(customer);
			return new ModelAndView("displayNewCustomerDetails","customer",customer);
		} catch (BillingServicesDownException e) {
			return new ModelAndView("signup","errorMessage",e.getMessage());
		}
	}
	@RequestMapping("/displayCustomerDetails")
	public ModelAndView registerAssociateAction(@RequestParam("customerID")int customerID) {
		Customer customer;
		try {
			customer = billingServices.getCustomerDetails(customerID);
			return new ModelAndView("displayCustomerDetails","customer",customer);
		} catch (CustomerDetailsNotFoundException | BillingServicesDownException e) {
			return new ModelAndView("getCustomerDetails","errorMessage",e.getMessage());
		}
	}
	@RequestMapping("/getAllCustomerDetails")
	public ModelAndView registerAssociateAction() {
		List<Customer> customers;
		try {
			customers = (List<Customer>) billingServices.getAllCustomerDetails();
			return new ModelAndView("displayAllCustomerDetails","customers",customers);
		} catch (BillingServicesDownException e) {
			return new ModelAndView("index","errorMessage",e.getMessage());
		}
		}
	@RequestMapping("/displayDeleteCustomerDetails")
	public ModelAndView deleteAssociateAction(@RequestParam("customerID")int customerID){
		try {
			billingServices.deleteCustomer(customerID);
			return new ModelAndView("deleteCustomerDetails","Message","Customer Details has been deleted");
		} catch (BillingServicesDownException | CustomerDetailsNotFoundException | PostpaidAccountNotFoundException e) {
			return new ModelAndView("deleteCustomerDetails","errorMessage",e.getMessage());
		}
		}
}
