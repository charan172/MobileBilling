package com.cg.billing.controllers;

import java.io.ByteArrayInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.billing.beans.Bill;
import com.cg.billing.exceptions.BillDetailsNotFoundException;
import com.cg.billing.exceptions.BillingServicesDownException;
import com.cg.billing.exceptions.CustomerDetailsNotFoundException;
import com.cg.billing.exceptions.InvalidBillMonthException;
import com.cg.billing.exceptions.PlanDetailsNotFoundException;
import com.cg.billing.exceptions.PostpaidAccountNotFoundException;
import com.cg.billing.services.BillingServices;
import com.cg.billing.services.GeneratePdfReport;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfWriter;

@Controller
public class BillController {
	@Autowired
	private BillingServices billingServices;
	@RequestMapping(value="/displayMonthlyBillDetails")
	public ModelAndView registerAssociateAction(@RequestParam("customerID")int customerID,
			@RequestParam("mobileNo")long mobileNo,@RequestParam("billMonth")String billMonth,
			@RequestParam("noOfLocalSMS")int noOfLocalSMS,@RequestParam("noOfStdSMS")int noOfStdSMS,
			@RequestParam("noOfLocalCalls")int noOfLocalCalls,@RequestParam("noOfStdCalls")int noOfStdCalls,
			@RequestParam("internetDataUsageUnits")int internetDataUsageUnits){
		Bill bill;
		try {
			bill = billingServices.generateMonthlyMobileBill(customerID, mobileNo, billMonth, noOfLocalSMS, noOfStdSMS, noOfLocalCalls, noOfStdCalls, internetDataUsageUnits);
			return new ModelAndView("displayBill","bill",bill);
		} catch (CustomerDetailsNotFoundException | PostpaidAccountNotFoundException | InvalidBillMonthException
				| BillingServicesDownException | PlanDetailsNotFoundException | BillDetailsNotFoundException e) {
			return new ModelAndView("generateMonthlyMobileBill","errorMessage",e.getMessage());
		}
	}
	@RequestMapping(value="/displayMonthlyMobileBillDetails")
	public ModelAndView registerAssociateAction(@RequestParam("customerID")int customerID,
			@RequestParam("mobileNo")long mobileNo,@RequestParam("billMonth")String billMonth) {
		Bill bill;
		try {
			bill = billingServices.getMobileBillDetails(customerID, mobileNo, billMonth);
			return new ModelAndView("displayBill","bill",bill);
		} catch (CustomerDetailsNotFoundException | PostpaidAccountNotFoundException | InvalidBillMonthException
				| BillDetailsNotFoundException | BillingServicesDownException | DocumentException | IOException e) {
			return new ModelAndView("getMobileBillDetails","errorMessage",e.getMessage());
		}
	}
	@RequestMapping(value="/displayPostPaidAccountAllMobileBillsDetails")
	public ModelAndView registerAssociateAction(@RequestParam("customerID")int customerID,
			@RequestParam("mobileNo")long mobileNo) {
		ArrayList<Bill> bills;
		try {
			bills = billingServices.getCustomerPostPaidAccountAllBillDetails(customerID, mobileNo);
			return new ModelAndView("displayPostPaidAccountAllMobileBillsDetails","bills",bills);
		} catch (CustomerDetailsNotFoundException | PostpaidAccountNotFoundException | BillingServicesDownException
				| BillDetailsNotFoundException e) {
			return new ModelAndView("getAllMobileBillDetails","errorMessage",e.getMessage());
		}
	}

	@RequestMapping(value = "/allBillsPdfReport", method = RequestMethod.GET,
			produces = MediaType.APPLICATION_PDF_VALUE )
	public ResponseEntity<InputStreamResource> getAllBillsPdfReport(@RequestParam("customerID")int customerID,@RequestParam("mobileNo")long mobileNo) throws IOException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException, BillDetailsNotFoundException, PlanDetailsNotFoundException, DocumentException {
		List<Bill> bills =  billingServices.getCustomerPostPaidAccountAllBillDetails(customerID, mobileNo);
		ByteArrayInputStream bis = GeneratePdfReport.billsReport(bills);
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Disposition", "inline; filename=billsreport.pdf");
		return ResponseEntity
				.ok()
				.headers(headers)
				.contentType(MediaType.APPLICATION_PDF)
				.body(new InputStreamResource(bis));
	}
	@RequestMapping(value = "/BillPdfReport", method = RequestMethod.GET,
			produces = MediaType.APPLICATION_PDF_VALUE )
	public ResponseEntity<InputStreamResource> getAllBillsPdfReport(@RequestParam("customerID")int customerID,@RequestParam("mobileNo")long mobileNo,@RequestParam("billMonth")String billMonth) throws IOException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException, BillDetailsNotFoundException, PlanDetailsNotFoundException, DocumentException, InvalidBillMonthException {
		Bill bills =  billingServices.getMobileBillDetails(customerID, mobileNo, billMonth);
		ByteArrayInputStream bis = GeneratePdfReport.billReport(bills);
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Disposition", "inline; filename=billreport.pdf");
		return ResponseEntity
				.ok()
				.headers(headers)
				.contentType(MediaType.APPLICATION_PDF)
				.body(new InputStreamResource(bis));
	}
}
